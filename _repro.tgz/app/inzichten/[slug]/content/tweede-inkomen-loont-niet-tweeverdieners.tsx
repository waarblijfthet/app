'use client';
import { useState } from "react";
import Link from "next/link";

const h2 = { fontSize: "1.6rem", color: "#16211F", marginTop: "2.5rem", marginBottom: "1rem", fontWeight: 300 } as const;
const p = { marginBottom: "1.25rem", fontWeight: 300 } as const;

function VoorNa({ rows }: { rows: [string, string, string][] }) {
  return (
    <div className="rounded-xl border my-6 overflow-hidden" style={{ borderColor: "#E6E9E7" }}>
      <div className="grid grid-cols-3" style={{ backgroundColor: "#16211F" }}>
        {["", "Voor", "Na"].map((h, i) => (
          <div key={i} className="px-4 py-2 font-body text-xs font-medium" style={{ color: "#F7F8F7" }}>{h}</div>
        ))}
      </div>
      {rows.map((r, i) => (
        <div key={i} className="grid grid-cols-3" style={{ backgroundColor: i % 2 ? "#FFFFFF" : "white" }}>
          <div className="px-4 py-2.5 font-body text-sm" style={{ color: "#16211F", fontWeight: 500 }}>{r[0]}</div>
          <div className="px-4 py-2.5 font-body text-sm" style={{ color: "#B03A2E" }}>{r[1]}</div>
          <div className="px-4 py-2.5 font-body text-sm" style={{ color: "#0B7A6E", fontWeight: 600 }}>{r[2]}</div>
        </div>
      ))}
    </div>
  );
}

function NettoRekentool() {
  const [bruto, setBruto] = useState("");
  const [tarief, setTarief] = useState(49.5);
  const [bso, setBso] = useState("");
  const [reis, setReis] = useState("");
  const [gemak, setGemak] = useState("200");

  const b = parseFloat(bruto.replace(/[^\d]/g, "")) || 0;
  const netto = Math.round(b * (1 - tarief / 100));
  const bsoVal = parseFloat(bso.replace(/[^\d]/g, "")) || 0;
  const reisVal = parseFloat(reis.replace(/[^\d]/g, "")) || 0;
  const gemakVal = parseFloat(gemak.replace(/[^\d]/g, "")) || 0;
  const totaalKosten = bsoVal + reisVal + gemakVal;
  const over = netto - totaalKosten;
  const heeftResultaat = b > 0;

  const inputStyle = {
    width: "100%", padding: "10px 14px", borderRadius: "10px",
    border: "1.5px solid #D9DEDC", fontFamily: "inherit", fontSize: "0.875rem",
    color: "#16211F", backgroundColor: "white", outline: "none",
  } as const;

  return (
    <div className="rounded-xl border my-8" style={{ backgroundColor: "#FFFFFF", borderColor: "#E6E9E7" }}>
      <div className="px-5 py-4 border-b" style={{ borderColor: "#E6E9E7" }}>
        <p className="font-body font-semibold text-sm" style={{ color: "#16211F" }}>
          Bereken je eigen netto-opbrengst
        </p>
        <p className="font-body text-xs mt-0.5" style={{ color: "#8B958F" }}>
          Vul je situatie in en zie wat er per maand overblijft
        </p>
      </div>
      <div className="p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="font-body text-xs font-medium mb-1.5 block" style={{ color: "#4A5A56" }}>
              Bruto inkomen / maand
            </label>
            <input
              type="text" inputMode="numeric" placeholder="€ 2.100"
              value={bruto} onChange={e => setBruto(e.target.value)}
              style={inputStyle}
            />
          </div>
          <div>
            <label className="font-body text-xs font-medium mb-1.5 block" style={{ color: "#4A5A56" }}>
              Marginaal belastingtarief
            </label>
            <select
              value={tarief} onChange={e => setTarief(Number(e.target.value))}
              style={{ ...inputStyle, backgroundColor: "white" }}
            >
              <option value={37.07}>37,07% (lager schijf)</option>
              <option value={49.5}>49,5% (hogere schijf)</option>
            </select>
          </div>
          <div>
            <label className="font-body text-xs font-medium mb-1.5 block" style={{ color: "#4A5A56" }}>
              BSO-kosten / maand (na toeslag)
            </label>
            <input
              type="text" inputMode="numeric" placeholder="€ 1.140"
              value={bso} onChange={e => setBso(e.target.value)}
              style={inputStyle}
            />
          </div>
          <div>
            <label className="font-body text-xs font-medium mb-1.5 block" style={{ color: "#4A5A56" }}>
              Reiskosten / maand
            </label>
            <input
              type="text" inputMode="numeric" placeholder="€ 185"
              value={reis} onChange={e => setReis(e.target.value)}
              style={inputStyle}
            />
          </div>
          <div>
            <label className="font-body text-xs font-medium mb-1.5 block" style={{ color: "#4A5A56" }}>
              Extra gemaksuitgaven (schatting)
            </label>
            <input
              type="text" inputMode="numeric" placeholder="€ 200"
              value={gemak} onChange={e => setGemak(e.target.value)}
              style={inputStyle}
            />
          </div>
        </div>

        {heeftResultaat && (
          <div className="rounded-xl border p-4 mt-2" style={{ backgroundColor: over >= 0 ? "#E7F1EE" : "#FEF2F2", borderColor: over >= 0 ? "#9CCFC4" : "#FCA5A5" }}>
            <div className="grid grid-cols-2 gap-y-2 text-sm font-body">
              <span style={{ color: "#4A5A56" }}>Netto na belasting</span>
              <span className="font-semibold text-right" style={{ color: "#16211F" }}>€{netto.toLocaleString("nl-NL")}</span>
              <span style={{ color: "#4A5A56" }}>Totale kosten</span>
              <span className="font-semibold text-right" style={{ color: "#B03A2E" }}>− €{totaalKosten.toLocaleString("nl-NL")}</span>
              <div className="col-span-2 border-t mt-1 pt-2" style={{ borderColor: over >= 0 ? "#9CCFC4" : "#FCA5A5" }}>
                <div className="flex justify-between">
                  <span className="font-semibold" style={{ color: over >= 0 ? "#16211F" : "#B03A2E" }}>Netto over</span>
                  <span className="font-bold text-base" style={{ color: over >= 0 ? "#0B7A6E" : "#B03A2E" }}>
                    {over >= 0 ? "+" : ""}€{over.toLocaleString("nl-NL")}
                  </span>
                </div>
              </div>
            </div>
            {over < 0 && (
              <p className="font-body text-xs mt-2" style={{ color: "#B03A2E" }}>
                Je legt toe op je inkomen. Minder dagen werken kan financieel voordeliger zijn.
              </p>
            )}
            {over >= 0 && over < 300 && (
              <p className="font-body text-xs mt-2" style={{ color: "#4A5A56" }}>
                Je houdt weinig over. Bereken of een dag minder werken de BSO-kosten genoeg verlaagt.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default function TweedeInkomenLoonNietTweeverdieners() {
  return (
    <>
      <div className="rounded-xl border p-4 mb-8" style={{ backgroundColor: "#FDF3E3", borderColor: "#F0D07A" }}>
        <p className="font-body text-sm" style={{ color: "#92600A" }}>
          <strong>Echte rekensom.</strong> Naam en details aangepast voor privacy. BSO-kosten en toeslag zijn sterk inkomensafhankelijk, check je eigen situatie via toeslagen.nl.
        </p>
      </div>

      <div className="rounded-xl p-5 mb-8" style={{ backgroundColor: "#E7F1EE", border: "1.5px solid #9CCFC4" }}>
        <p className="font-body font-semibold text-sm mb-3" style={{ color: "#16211F" }}>Na dit artikel weet je:</p>
        <ul className="space-y-1.5">
          {[
            "Waarom een goed salaris na aftrek van BSO, belasting en reiskosten soms niets oplevert",
            "Hoe de rekensom er voor jouw situatie uitziet, vul je eigen getallen in",
            "Wanneer minder dagen werken netto méér oplevert",
          ].map((item, i) => (
            <li key={i} className="flex gap-2 font-body text-sm" style={{ color: "#16211F" }}>
              <span className="mt-0.5 shrink-0" style={{ color: "#0B7A6E" }}>✓</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      <p className="font-body" style={{ ...p, fontWeight: 400, color: "#16211F", fontSize: "1.05rem" }}>
        Je werkt vier dagen, verdient een fatsoenlijk salaris, en toch loopt het geld aan het einde van de maand gewoon op. Hoe? Omdat een groot deel van je tweede inkomen direct opgaat aan de kosten die dat inkomen met zich meebrengt, <strong>zonder dat je het in de gaten hebt.</strong>
      </p>

      <h2 className="font-display" style={h2}>De vier kostenvreters van het tweede inkomen</h2>
      <p className="font-body text-text-soft" style={p}>
        <strong>1. Belasting.</strong> Nederland heeft een progressief belastingstelsel. Als het gezinsinkomen al boven circa €75.518 bruto ligt, wordt elk extra euro van het tweede inkomen belast tegen 49,5%. Van €2.500 bruto per maand blijft dan netto circa €1.270 over, vóór kosten.
      </p>
      <p className="font-body text-text-soft" style={p}>
        <strong>2. BSO.</strong> Buitenschoolse opvang voor één kind kost in 2026 gemiddeld €900 tot €1.400 per maand voor vijf dagen. Bij een gezinsinkomen boven €90.000 bruto is de kinderopvangtoeslag minimaal, nog geen 33%. Bij twee kinderen op BSO lopen de netto kosten al gauw op tot €1.200 tot €1.800 per maand.
      </p>
      <p className="font-body text-text-soft" style={p}>
        <strong>3. Reiskosten.</strong> OV-abonnement, brandstof, parkeren, slijtage. Gemiddeld €200 tot €400 per maand voor een forens.
      </p>
      <p className="font-body text-text-soft" style={p}>
        <strong>4. Tijdgebrek dat geld kost.</strong> Meer kant-en-klaarmaaltijden, meer eten bestellen, meer mensen inhuren voor klussen. Makkelijk €150 tot €300 per maand extra.
      </p>

      <NettoRekentool />

      <h2 className="font-display" style={h2}>Cas: Marieke &amp; Rick, €2.100 bruto, €280 netto over</h2>
      <p className="font-body text-text-soft" style={p}>
        Marieke (36) en Rick (38), twee kinderen (4 en 7 jaar). Rick verdient €4.800 bruto, Marieke €2.100 bruto (4 dagen). Ze dachten dat Marieke&apos;s inkomen circa €1.400 netto per maand opleverde. Ze hadden het nooit exact nageteld.
      </p>

      <div className="rounded-xl border my-6 overflow-hidden" style={{ borderColor: "#E6E9E7" }}>
        <div className="grid grid-cols-2" style={{ backgroundColor: "#16211F" }}>
          <div className="px-4 py-2 font-body text-xs font-medium" style={{ color: "#F7F8F7" }}>Post</div>
          <div className="px-4 py-2 font-body text-xs font-medium" style={{ color: "#F7F8F7" }}>Per maand</div>
        </div>
        {[
          ["Marieke bruto inkomen", "€2.100"],
          ["Netto na belasting (49,5% schijf)", "€1.260"],
          ["BSO twee kinderen, 4 dagen (na toeslag)", "- €1.140"],
          ["Reiskosten OV", "- €185"],
          ["Extra eten/bezorging door tijdgebrek", "- €210"],
          ["Werkkleding, kapper, etc.", "- €75"],
          ["Netto wat overblijft", "- €350"],
        ].map(([label, bedrag], i) => (
          <div key={i} className="grid grid-cols-2" style={{ backgroundColor: i % 2 ? "#FFFFFF" : "white" }}>
            <div className="px-4 py-2.5 font-body text-sm" style={{ color: "#16211F", fontWeight: i === 6 ? 600 : 400 }}>{label}</div>
            <div className="px-4 py-2.5 font-body text-sm" style={{ color: i === 6 ? "#B03A2E" : "#16211F", fontWeight: i === 6 ? 600 : 400 }}>{bedrag}</div>
          </div>
        ))}
      </div>

      <p className="font-body text-text-soft" style={p}>
        Marieke&apos;s inkomen leverde per saldo een tekort op, zonder dat ze het doorhadden. Tel je de pensioenopbouw via haar werkgever mee (circa €300 per maand annualized), dan is het vrijwel break-even. Maar de stress, het haasten en het gevoel van krapte: dat was reëel.
      </p>

      <VoorNa rows={[
        ["Werkdagen Marieke", "4 dagen", "3 dagen"],
        ["BSO-kosten/mnd", "€1.140 netto", "€855 netto"],
        ["Netto effect per maand", "- €350", "+ €180"],
        ["Gevoel thuis", "Gejaagd", "Merkbaar rustiger"],
      ]} />

      <p className="font-body text-text-soft" style={p}>
        Ze gingen terug van 4 naar 3 dagen. De BSO-kosten daalden met één dag (€285 netto minder). Haar inkomen daalde, maar de kosten daalden méér. Netto effect: <strong>€180 per maand meer over</strong>, plus aanzienlijk minder stress.
      </p>

      <div className="rounded-xl p-5 my-6" style={{ backgroundColor: "#FEF9EC", border: "1.5px solid #E8C870" }}>
        <p className="font-body font-semibold text-xs uppercase tracking-wide mb-2" style={{ color: "#92600A" }}>De BSO-kosten zijn tijdelijk</p>
        <p className="font-body text-sm" style={{ color: "#0A6A5F" }}>
          Als de kinderen naar groep 5 gaan, vervallen de BSO-kosten. De rekensom kantelt dan volledig ten gunste van werken. De vraag is alleen of je werkpatroon <em>nu</em> klopt bij je leven en je financiën.
        </p>
      </div>

      <h2 className="font-display" style={h2}>Betekent dit dat je beter kunt stoppen?</h2>
      <p className="font-body text-text-soft" style={p}>
        Niet per se. Elke dag dat je werkt bouw je pensioen op. Een gat in je cv heeft effect op je carrière. En werk is voor veel mensen meer dan inkomen. Bovendien: de BSO-kosten zijn tijdelijk. Als de kinderen naar groep 5 gaan, vervalt de BSO, en kantelt de rekensom volledig.
      </p>
      <p className="font-body text-text-soft" style={p}>
        De vraag is niet &ldquo;stop ik of niet&rdquo; maar: <strong>klopt mijn werkpatroon bij mijn leven en mijn financiën?</strong> Vier dagen werken terwijl de netto opbrengst nihil is en de stress hoog, is geen vanzelfsprekende keuze.
      </p>
      <p className="font-body text-text-soft" style={p}>
        Lees ook:{" "}
        <Link href="/inzichten/tweeverdieners-toch-krap" style={{ color: "#0B7A6E", textDecoration: "none" }} className="hover:underline">tweeverdieners en toch krap, hoe kan dat?</Link>{" "}
        en{" "}
        <Link href="/inzichten/bso-kosten-tweede-inkomen-zo-draaiden-we-het-om" style={{ color: "#0B7A6E", textDecoration: "none" }} className="hover:underline">de BSO slokte ons tweede inkomen op, zo draaiden we het om</Link>.
      </p>
      <p className="font-body text-text-soft" style={p}>
        Wil je jouw eigen rekensom zien?{" "}
        <Link href="/analyse" style={{ color: "#0B7A6E", textDecoration: "none" }} className="hover:underline">Doe de analyse</Link>{" "}
       , dan zie je in 15 minuten hoeveel het tweede inkomen jou netto oplevert. Of bespreek het concreet in een{" "}
        <Link href="/adviesgesprek" style={{ color: "#0B7A6E", textDecoration: "none" }} className="hover:underline">eenmalig adviesgesprek van €125</Link>.
      </p>
    </>
  );
}
