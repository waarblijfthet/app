import { NextRequest, NextResponse } from "next/server";
import { createServiceClient } from "@/lib/supabase-service";
import { isAdminRequest } from "@/lib/admin-auth";
import { Doelgroep, DOELGROEPEN } from "@/lib/prospects/types";

export const dynamic = "force-dynamic";

interface RijOverride {
  naam?: string;
  doelgroep?: string;
  plaats?: string;
}

// POST /api/admin/prospects/review
// Body: { ids: string[], actie: "goedkeuren" | "afwijzen", overrides?: Record<id, { naam?, doelgroep?, plaats? }> }
// Goedkeuren zet het contact in outreach_contacts (status nieuw). overrides
// laat de admin-UI een gecorrigeerde naam/doelgroep/plaats meesturen in
// dezelfde request in plaats van eerst een losse PATCH te doen (CLAUDE.md-
// opdracht "prospect-zoeker verbeterronde", deel 1.5).
export async function POST(req: NextRequest) {
  if (!(await isAdminRequest())) {
    return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });
  }
  const supabase = createServiceClient();
  const { ids, actie, overrides } = await req.json();

  if (!Array.isArray(ids) || ids.length === 0) {
    return NextResponse.json({ error: "ids ontbreken" }, { status: 400 });
  }
  if (actie !== "goedkeuren" && actie !== "afwijzen") {
    return NextResponse.json({ error: "actie moet 'goedkeuren' of 'afwijzen' zijn" }, { status: 400 });
  }
  const overrideMap: Record<string, RijOverride> =
    overrides && typeof overrides === "object" ? overrides : {};

  if (actie === "afwijzen") {
    const { data: afgewezen, error } = await supabase
      .from("prospects")
      .update({ status: "afgewezen" })
      .in("id", ids)
      .eq("status", "gevonden")
      .select("id");
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ ok: true, ids: (afgewezen ?? []).map((r) => r.id) });
  }

  const { data: prospects, error: fetchError } = await supabase
    .from("prospects").select("*").in("id", ids).eq("status", "gevonden");
  if (fetchError) return NextResponse.json({ error: fetchError.message }, { status: 500 });

  const emails = (prospects ?? []).map((p) => p.email);
  const { data: geblokkeerd } = await supabase
    .from("email_blocklist")
    .select("email, reden")
    .in("email", emails);
  const blocklistMap = new Map((geblokkeerd ?? []).map((b) => [b.email, b.reden]));

  const resultaten: { id: string; naam: string; ok: boolean; fout?: string }[] = [];
  for (const p of prospects ?? []) {
    const override = overrideMap[p.id] ?? {};
    const naam = (typeof override.naam === "string" ? override.naam : p.naam)?.trim() ?? "";
    const doelgroep = typeof override.doelgroep === "string" ? override.doelgroep : p.doelgroep;
    const plaats = typeof override.plaats === "string" ? override.plaats.trim() || null : p.plaats ?? null;

    if (blocklistMap.has(p.email)) {
      resultaten.push({
        id: p.id, naam, ok: false,
        fout: `Staat op de blocklist (${blocklistMap.get(p.email)})`,
      });
      continue;
    }
    // Een onbekende of lege doelgroep is een fout die ik moet zien, niet iets
    // dat stil wordt goedgemaakt met een gok naar relatietherapeuten (deel 3.3).
    if (!doelgroep || !DOELGROEPEN.includes(doelgroep as Doelgroep)) {
      resultaten.push({ id: p.id, naam, ok: false, fout: "doelgroep niet gekozen" });
      continue;
    }
    if (!naam) {
      resultaten.push({ id: p.id, naam, ok: false, fout: "naam ontbreekt" });
      continue;
    }
    const { error } = await supabase.from("outreach_contacts").insert({
      naam,
      email: p.email,
      doelgroep,
      plaats,
      praktijk: p.praktijk ?? null,
      website: p.website ?? null,
      bron_url: p.bron_url ?? null,
      context: p.context ?? null,
      doelgroep_score: p.doelgroep_score ?? 0,
    });
    if (error && error.code !== "23505") {
      resultaten.push({ id: p.id, naam, ok: false, fout: error.message });
      continue;
    }
    // 23505 = stond al in outreach; prospect alsnog als goedgekeurd markeren
    await supabase.from("prospects").update({ status: "goedgekeurd" }).eq("id", p.id);
    resultaten.push({ id: p.id, naam, ok: true });
  }

  return NextResponse.json({ resultaten });
}

// PATCH /api/admin/prospects/review
// Body: { id: string, naam?: string, doelgroep?: string }
export async function PATCH(req: NextRequest) {
  if (!(await isAdminRequest())) {
    return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });
  }
  const supabase = createServiceClient();
  const { id, naam, doelgroep, plaats } = await req.json();
  if (!id) return NextResponse.json({ error: "id ontbreekt" }, { status: 400 });

  const update: { naam?: string; doelgroep?: string; plaats?: string | null } = {};
  if (typeof naam === "string" && naam.trim()) update.naam = naam.trim();
  if (typeof doelgroep === "string") {
    if (!DOELGROEPEN.includes(doelgroep as Doelgroep)) {
      return NextResponse.json({ error: "ongeldige doelgroep" }, { status: 400 });
    }
    update.doelgroep = doelgroep;
  }
  if (typeof plaats === "string") update.plaats = plaats.trim() || null;
  if (Object.keys(update).length === 0) {
    return NextResponse.json({ error: "niets om bij te werken" }, { status: 400 });
  }

  const { data, error } = await supabase
    .from("prospects").update(update).eq("id", id).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
