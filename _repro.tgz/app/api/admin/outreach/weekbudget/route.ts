import { NextResponse } from "next/server";
import { createServiceClient } from "@/lib/supabase-service";
import { isAdminRequest } from "@/lib/admin-auth";
import { berekenDagbudget } from "@/lib/outreach/dagbudget";

// Vervangen door /api/admin/outreach/dagbudget (1-aug-2026). Kon niet
// verwijderd worden (permissiefout op deze mount), dus blijft als
// alias die dezelfde (nu dagelijkse) berekening teruggeeft. Nieuwe code
// moet /api/admin/outreach/dagbudget gebruiken.
export async function GET() {
  if (!(await isAdminRequest())) {
    return NextResponse.json({ error: "Niet ingelogd" }, { status: 401 });
  }
  const supabase = createServiceClient();
  try {
    const resultaat = await berekenDagbudget(supabase);
    return NextResponse.json(resultaat);
  } catch (e) {
    const message = e instanceof Error ? e.message : "Kon dagbudget niet berekenen.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
